def main():
    try:
        with open("numbers.txt", "r") as file:
            total = sum(int(line.strip()) for line in file if line.strip().isdigit())
        print("Total sum of numbers:", total)
    except FileNotFoundError:
        print("Error: Cannot open file 'numbers.txt'.")

if __name__ == "__main__":
    main()