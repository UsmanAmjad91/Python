import string
from collections import Counter

def clean_word(word):
    return word.strip(string.punctuation).lower()

def main():
    try:
        with open("text.txt", "r") as file:
            words = []
            for line in file:
                words.extend([clean_word(word) for word in line.split()])
            word_count = Counter(words)
        print("Word Frequency:")
        for word, count in word_count.items():
            print(f"{word}: {count}")
    except FileNotFoundError:
        print("Error: Cannot open file 'text.txt'.")

if __name__ == "__main__":
    main()