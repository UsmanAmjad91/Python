from django.http import JsonResponse

def hello(request):
    return JsonResponse({'message': 'Users app is present'})
