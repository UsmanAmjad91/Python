from django.urls import path
from . import views

urlpatterns = [
    path('users/hello', views.hello, name='users-hello'),
]
