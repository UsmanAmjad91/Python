from django.urls import path
from . import views

urlpatterns = [
    path('api/tutorials/', views.TutorialListCreate.as_view(), name='tutorial-list'),
    path('api/tutorials/<int:pk>', views.TutorialDetail.as_view(), name='tutorial-detail'),
    path('api/tutorials/published', views.PublishedTutorials.as_view(), name='tutorial-published'),
]
