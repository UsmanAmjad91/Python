from rest_framework import generics
from .models import Tutorial
from .serializers import TutorialSerializer

class TutorialListCreate(generics.ListCreateAPIView):
    queryset = Tutorial.objects.all()
    serializer_class = TutorialSerializer

class TutorialDetail(generics.RetrieveAPIView):
    queryset = Tutorial.objects.all()
    serializer_class = TutorialSerializer

class PublishedTutorials(generics.ListAPIView):
    queryset = Tutorial.objects.filter(published=True)
    serializer_class = TutorialSerializer
