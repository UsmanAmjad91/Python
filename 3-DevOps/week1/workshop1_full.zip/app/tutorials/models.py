from django.db import models

class Tutorial(models.Model):
    title = models.CharField(max_length=200)
    tutorial_url = models.URLField(blank=True)
    image_path = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    published = models.BooleanField(default=False)

    def __str__(self):
        return self.title
