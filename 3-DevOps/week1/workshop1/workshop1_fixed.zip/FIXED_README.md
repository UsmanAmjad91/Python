Quickstart:
- Create venv, install pip==21.1.2, then `pip install -r app/requirements.txt`
- For Docker: `docker compose up -d --build` then `docker compose exec web python manage.py migrate --noinput`
