from django.contrib import admin
from .models import Tutorial

admin.site.register(Tutorial)
