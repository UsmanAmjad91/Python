from django.urls import path
from . import views
urlpatterns = [
    path('api/tutorials/', views.tutorials_list, name='tutorials-list'),
    path('api/tutorials/<int:pk>', views.tutorials_detail, name='tutorials-detail'),
    path('api/tutorials/published', views.tutorials_published, name='tutorials-published'),
]
