from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Tutorial
from .serializers import TutorialSerializer

@api_view(['GET','POST'])
def tutorials_list(request):
    if request.method == 'GET':
        return Response(TutorialSerializer(Tutorial.objects.all(), many=True).data)
    serializer = TutorialSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def tutorials_detail(request, pk):
    try:
        item = Tutorial.objects.get(pk=pk)
    except Tutorial.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    if request.method == 'GET':
        return Response(TutorialSerializer(item).data)
    if request.method == 'PUT':
        serializer = TutorialSerializer(item, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save(); return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    item.delete(); return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET'])
def tutorials_published(request):
    qs = Tutorial.objects.filter(published=True)
    return Response(TutorialSerializer(qs, many=True).data)
