# Flask SQL API — `portfolio_db` (Auth + DB Sessions + Posts)

A ready-to-run Flask + PostgreSQL API for your portfolio project:
- Users with **hashed passwords**
- Login with **Flask-Login**
- **Server-side sessions stored in DB** via Flask-Session (table: `sessions`)
- Authenticated users can **create posts**
- Performance: B-tree index on `posts.title`

## Project Structure

```
flask_sql_api_portfolio_db/
├─ .env.example
├─ README.md
├─ requirements.txt
├─ wsgi.py
├─ insomnia_collection.json
├─ sql/
│  ├─ schema.sql            # creates users, posts, sessions
│  └─ indexes.sql           # extra performance indexes
└─ src/
   ├─ __init__.py
   ├─ config.py
   ├─ extensions.py
   ├─ models.py
   ├─ auth.py
   └─ posts.py
```

---

## Step-by-Step: Run Locally

### 1) Create and activate a virtual environment
```bash
python -m venv .venv
# Windows:
. .venv/Scripts/activate
# macOS/Linux:
source .venv/bin/activate
```

### 2) Install dependencies
```bash
pip install -r requirements.txt
```

### 3) Create PostgreSQL database
```bash
createdb portfolio_db
# Or in psql:
# CREATE DATABASE portfolio_db;
```

### 4) Configure environment
```bash
cp .env.example .env
# If needed, edit .env for your Postgres username/password/host/port
```

### 5) (Option A) Create tables via Flask-Migrate (recommended)
```bash
export FLASK_APP=wsgi.py        # PowerShell: $env:FLASK_APP="wsgi.py"
flask db init
flask db migrate -m "init tables"
flask db upgrade
```
> This creates **users** and **posts** from ORM models.  
> The **sessions** table is created automatically by Flask-Session at runtime.  
> If you prefer to pre-create `sessions`, use Option B.

### 5) (Option B) Create tables via SQL
Run DDL (creates **users**, **posts**, and **sessions** explicitly):
```bash
psql -d portfolio_db -f sql/schema.sql
```

### 6) Run the server
```bash
flask run
# http://127.0.0.1:5000
```

### 7) Test with Insomnia
- Import `insomnia_collection.json` (File → Import → From File).
- Use requests in order: **Register → Login → Create Post → List Posts → Logout**.

---

## API Reference

| Endpoint         | Method | Auth | Description                                |
|------------------|--------|------|--------------------------------------------|
| `/auth/register` | POST   | No   | Create user (hashed password)              |
| `/auth/login`    | POST   | No   | Start session (DB-backed)                  |
| `/auth/logout`   | POST   | Yes  | End session                                |
| `/posts/`        | GET    | No   | List posts with author                     |
| `/posts/`        | POST   | Yes  | Create post (title, content)               |

**Register**
```json
{ "username": "usman", "password": "mypassword123" }
```
**Login**
```json
{ "username": "usman", "password": "mypassword123" }
```
**Create Post**
```json
{ "title": "My First Post", "content": "Hello Flask + PostgreSQL!" }
```

---

## Performance Indexes
- B-tree index: `posts.title` (ORM-defined as `ix_posts_title`).
- Optional extra indexes in `sql/indexes.sql` (including HASH example).

---
