-- Create tables for portfolio_db: users, posts, sessions

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index on posts.title (B-tree, default) for faster search/filter
CREATE INDEX IF NOT EXISTS ix_posts_title ON posts (title);

-- Sessions table used by Flask-Session when SESSION_TYPE='sqlalchemy'.
-- This schema matches common Flask-Session expectations.
CREATE TABLE IF NOT EXISTS sessions (
    session_id VARCHAR(255) PRIMARY KEY,
    data TEXT,
    expiry TIMESTAMP WITH TIME ZONE
);

-- Helpful index for expiry-based cleanup
CREATE INDEX IF NOT EXISTS ix_sessions_expiry ON sessions (expiry);
