-- Optional: extra indexes for performance tuning

-- Equality-only HASH index example (PostgreSQL 10+)
-- This can speed up queries like: SELECT * FROM posts WHERE title = '...';
-- Use only if equality filters on title are frequent.
CREATE INDEX IF NOT EXISTS idx_posts_title_hash ON posts USING HASH (title);
