from flask import Flask
from .config import Config
from .extensions import db, migrate, login_manager, session_ext

def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    # Init DB first
    db.init_app(app)
    migrate.init_app(app, db)

    # Flask-Login
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    # Make SQLAlchemy instance available to Flask-Session
    app.config["SESSION_SQLALCHEMY"] = db
    app.config.setdefault("SESSION_SQLALCHEMY_TABLE", "sessions")

    # Initialize Flask-Session (DB-backed)
    session_ext.init_app(app)

    # Import models so migrations can see them
    from .models import User, Post  # noqa: F401

    @login_manager.user_loader
    def load_user(user_id: str):
        return db.session.get(User, int(user_id))

    # Blueprints
    from .auth import auth_bp
    from .posts import posts_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(posts_bp)

    return app
