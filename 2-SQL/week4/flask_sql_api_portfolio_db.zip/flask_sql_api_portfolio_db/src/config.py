import os

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg2://postgres:postgres@localhost:5432/portfolio_db",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Server-side session settings
    SESSION_TYPE = "sqlalchemy"       # Flask-Session uses DB
    SESSION_USE_SIGNER = True         # Sign session IDs
    SESSION_PERMANENT = True          # Use permanent sessions unless specified
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 7  # 7 days (seconds)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
