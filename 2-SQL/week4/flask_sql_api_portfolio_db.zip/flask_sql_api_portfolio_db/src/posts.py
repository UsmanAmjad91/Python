from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from .extensions import db
from .models import Post

posts_bp = Blueprint("posts", __name__, url_prefix="/posts")

@posts_bp.route("/", methods=["POST"])
@login_required
def create_post():
    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "").strip()
    content = (data.get("content") or "").strip()

    if not title or not content:
        return jsonify({"error": "title and content are required"}), 400

    post = Post(title=title, content=content, user_id=current_user.id)
    db.session.add(post)
    db.session.commit()

    return jsonify({"message": "Post created successfully", "post": post.to_dict()}), 201


@posts_bp.route("/", methods=["GET"])
def list_posts():
    posts = Post.query.order_by(Post.created_at.desc()).all()
    return jsonify([p.to_dict() for p in posts]), 200
