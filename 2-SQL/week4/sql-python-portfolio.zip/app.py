# from flask import Flask
#  from config import Config
# from extensions import db, migrate, session
# from flask_session import Session
# from routes import bp

# def create_app():
#     app = Flask(__name__)
#     app.config.from_object(Config)

#     db.init_app(app)
#     migrate.init_app(app, db)
#     app.config['SESSION_SQLALCHEMY'] = db
#     session_sqlalchemy.init_app(app)
#     Session(app)

#     app.register_blueprint(bp)

#     return app

# app = create_app()

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0')
from flask import Flask
from extensions import db, migrate
from models import User, Post, Like
from routes import api_bp

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost:5432/portfolio_db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = 'your-secret-key'

    db.init_app(app)
    migrate.init_app(app, db)
    
    app.register_blueprint(api_bp)
    # ---------------- Base URL ----------------
    @app.route("/")
    def home():
        return "<h1>Welcome to My Flask App!</h1>"

    return app

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)