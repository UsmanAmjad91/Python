from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db
from models import User, Post, Like
from functools import wraps

# Create API blueprint
api_bp = Blueprint("api", __name__, url_prefix="/api")

# ---------------- Helper ----------------
def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return func(*args, **kwargs)
    return wrapper
# Base URL route
@api_bp.route("/")
def home():
    return "Welcome to My Flask App!"
# ---------------- Root ----------------

def api_root():
    return {
        "message": "Welcome to SQL-Python Portfolio API",
        "endpoints": [
            "/auth/register",
            "/auth/login",
            "/auth/logout",
            "/auth/me",
            "/users",
            "/posts"
        ]
    }

# ---------------- Auth ----------------
@api_bp.route('/auth/register', methods=['POST'])
def register():
    data = request.json
    if not data.get('username') or not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Missing fields'}), 400
    if User.query.filter((User.username==data['username']) | (User.email==data['email'])).first():
        return jsonify({'error': 'User already exists'}), 400
    user = User(
        username=data['username'],
        email=data['email'],
        password_hash=generate_password_hash(data['password'])
    )
    db.session.add(user)
    db.session.commit()
    return jsonify(user.to_dict()), 201

@api_bp.route('/auth/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(username=data.get('username')).first()
    if user and check_password_hash(user.password_hash, data.get('password')):
        session['user_id'] = user.id
        return jsonify({'message': 'Login successful', 'user': user.to_dict()})
    return jsonify({'error': 'Invalid credentials'}), 401

@api_bp.route('/auth/logout', methods=['POST'])
@login_required
def logout():
    session.clear()
    return jsonify({'message': 'Logged out'})

@api_bp.route('/auth/me', methods=['GET'])
@login_required
def me():
    user = User.query.get(session['user_id'])
    return jsonify(user.to_dict())

# ---------------- Users CRUD ----------------
@api_bp.route('/users', methods=['GET'])
def list_users():
    users = User.query.all()
    return jsonify([u.to_dict() for u in users])

@api_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@api_bp.route('/users/<int:user_id>', methods=['PUT'])
@login_required
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id != session['user_id']:
        return jsonify({'error': 'Forbidden'}), 403
    data = request.json
    if 'username' in data:
        user.username = data['username']
    if 'email' in data:
        user.email = data['email']
    if 'password' in data:
        user.password_hash = generate_password_hash(data['password'])
    db.session.commit()
    return jsonify(user.to_dict())

@api_bp.route('/users/<int:user_id>', methods=['DELETE'])
@login_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id != session['user_id']:
        return jsonify({'error': 'Forbidden'}), 403
    db.session.delete(user)
    db.session.commit()
    session.clear()
    return jsonify({'message': 'User deleted'})

# ---------------- Posts CRUD ----------------
@api_bp.route('/posts', methods=['POST'])
@login_required
def create_post():
    data = request.json
    if not data.get('title') or not data.get('content'):
        return jsonify({'error': 'Missing fields'}), 400
    post = Post(
        title=data['title'],
        content=data['content'],
        user_id=session['user_id']
    )
    db.session.add(post)
    db.session.commit()
    return jsonify(post.to_dict()), 201

@api_bp.route('/posts', methods=['GET'])
def list_posts():
    posts = Post.query.all()
    return jsonify([p.to_dict() for p in posts])

@api_bp.route('/posts/<int:post_id>', methods=['GET'])
def get_post(post_id):
    post = Post.query.get_or_404(post_id)
    return jsonify(post.to_dict())

@api_bp.route('/posts/<int:post_id>', methods=['PUT'])
@login_required
def update_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != session['user_id']:
        return jsonify({'error': 'Forbidden'}), 403
    data = request.json
    if 'title' in data:
        post.title = data['title']
    if 'content' in data:
        post.content = data['content']
    db.session.commit()
    return jsonify(post.to_dict())

@api_bp.route('/posts/<int:post_id>', methods=['DELETE'])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != session['user_id']:
        return jsonify({'error': 'Forbidden'}), 403
    db.session.delete(post)
    db.session.commit()
    return jsonify({'message': 'Post deleted'})

# ---------------- Likes ----------------
@api_bp.route('/posts/<int:post_id>/like', methods=['POST'])
@login_required
def like_post(post_id):
    post = Post.query.get_or_404(post_id)
    if Like.query.filter_by(post_id=post_id, user_id=session['user_id']).first():
        return jsonify({'error': 'Already liked'}), 400
    like = Like(user_id=session['user_id'], post_id=post_id)
    db.session.add(like)
    db.session.commit()
    return jsonify({'message': 'Post liked'})

@api_bp.route('/posts/<int:post_id>/unlike', methods=['POST'])
@login_required
def unlike_post(post_id):
    like = Like.query.filter_by(post_id=post_id, user_id=session['user_id']).first()
    if not like:
        return jsonify({'error': 'Not liked yet'}), 400
    db.session.delete(like)
    db.session.commit()
    return jsonify({'message': 'Post unliked'})

@api_bp.route('/posts/<int:post_id>/likes', methods=['GET'])
def list_likes(post_id):
    likes = Like.query.filter_by(post_id=post_id).all()
    return jsonify([{'user_id': l.user_id, 'post_id': l.post_id, 'created_at': l.created_at.isoformat()} for l in likes])
